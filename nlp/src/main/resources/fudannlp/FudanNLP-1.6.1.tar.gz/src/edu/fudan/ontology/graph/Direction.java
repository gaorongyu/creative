package edu.fudan.ontology.graph;

public enum Direction{
	BOTH,
	UP,
	SUB;
};