package edu.fudan.ontology.graph;
/**
 * 词
 * @author Xipeng
 *
 */
public class Word {
	
	int id;
	String word;

	public Word(String word) {
		this.word = word;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
