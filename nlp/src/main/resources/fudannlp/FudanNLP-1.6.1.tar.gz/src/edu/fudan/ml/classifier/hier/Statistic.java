package edu.fudan.ml.classifier.hier;

public class Statistic {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		

	}

}
