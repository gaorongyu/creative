/**
 * 
 */
/**
 * @author Xipeng
 *
 */
package edu.fudan.nlp.similarity.train;