/**
 * 
 */
/**
 * @author xpqiu
 *
 */
package org.fnlp.app.lucene;