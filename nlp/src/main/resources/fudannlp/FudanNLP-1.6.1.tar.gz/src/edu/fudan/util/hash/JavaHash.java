package edu.fudan.util.hash;

public class JavaHash extends AbstractHashCode {
    public int hashcode(String str) {
        return str.hashCode();
    }
}
