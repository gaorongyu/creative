package edu.fudan.ml.types.featurecluster;

public abstract class AbstractDistance {
    public abstract double cal(ClassData cd1, ClassData cd2);
}
