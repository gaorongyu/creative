/**
 * 	损失计算函数.  
 * <p>This file is part of FudanNLP.

 * <p>FudanNLP is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * <p>FudanNLP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.

 * <p>You should have received a copy of the GNU General Public License
 * along with FudanNLP.  If not, see <a href="http://www.gnu.org/licenses/">
 * http://www.gnu.org/licenses/</a>.

 * <p>Copyright 2009-2012 fnlp.org. All rights reserved.
 *   
 * @author <a href="mailto:xpqiu@fudan.edu.cn">fnlp.org</a>  
 * @since FudanNLP 1.5
 * @version 1.0.0  
 * @date 2012-11-14
 */
package edu.fudan.ml.loss;