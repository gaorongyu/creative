/**
 * FNLP数据内部格式
 * @author Xipeng
 *
 */
package edu.fudan.nlp.corpus.fnlp;