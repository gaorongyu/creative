package edu.fudan.util;
/**
 * 实现回调函数
 * @author xpqiu
 *
 */
public interface ICallback {
	public void execute();
}
